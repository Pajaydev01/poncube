import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DatasService {
  category: any;

  constructor() { }

  save_category(item){
    this.category=item;
  }

  fetch_category(){
    return this.category;
  }
}
