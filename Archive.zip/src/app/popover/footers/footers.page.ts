import { Component, OnInit, Input} from '@angular/core';
import { LoadingController, ModalController, IonInfiniteScroll, IonContent,NavController,Platform} from '@ionic/angular';
import { ProviderService } from '../../providers/provider.service';
import { PopoverController } from '@ionic/angular';

@Component({
  selector: 'app-footers',
  templateUrl: './footers.page.html',
  styleUrls: ['./footers.page.scss'],
})
export class FootersPage implements OnInit {
@Input() type:any;
@Input() dp:any;
@Input() name:any;
information:boolean=false;
c_service:boolean=false;
extra:boolean=false;
menu:boolean=false;
isLoading:boolean;
  constructor(public navy: NavController,
    public provider:ProviderService,
    public loadingController: LoadingController,public popoverController: PopoverController,) { }

  ngOnInit() {
  }

  ionViewWillEnter(){
    if(this.type==="information"){
      this.information=true;
    }
    else if(this.type==="c_service"){
      this.c_service=true;
    }
    else if(this.type==="extra"){
      this.extra=true;
    }
    else if(this.type==="menu"){
      this.menu=true;
    }
  }

  //direct routes here
  route(param){
    this.navy.navigateForward(param);
    this.popoverController.dismiss();
  }

  //logout here
  logout(){
    this.loadingPresent('Logging you out..');
    let session_id=localStorage.getItem('session_id');
  this.provider.logout(session_id).subscribe(res=>{
    localStorage.clear();
    this.loadingDismiss();
    this.popoverController.dismiss();
  });
  }

  //loading controller here
  async loadingPresent(params) {
    this.isLoading = true;
    return await this.loadingController.create({
      message:params,
      spinner: 'circles'
    }).then(a => {
      a.present().then(() => {
        console.log('loading presented');
        if (!this.isLoading) {
          a.dismiss().then(() => console.log('abort laoding'));
        }
      });
    });
  }


  async loadingDismiss() {
    this.isLoading = false;
    return await this.loadingController.dismiss().then(() => console.log('loading dismissed'));
  }
}
