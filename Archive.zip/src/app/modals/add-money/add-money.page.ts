import { Component, OnInit, Input} from '@angular/core';
import { PaystackOptions } from 'angular4-paystack';
import { LoadingController, ModalController, ToastController,IonContent, NavController } from '@ionic/angular';
import { ProviderService } from '../../providers/provider.service';
@Component({
  selector: 'app-add-money',
  templateUrl: './add-money.page.html',
  styleUrls: ['./add-money.page.scss'],
})
export class AddMoneyPage implements OnInit {
@Input() usermail:string;
amnt:number;
pays:boolean=true;
payss:boolean=false;
resp:any;
isLoading:boolean;
refs:any;
options: PaystackOptions = {
     amount: 0,
     email: '',
     ref:''
  }

  constructor( public modalController: ModalController,public provider:ProviderService,public loadingController: LoadingController,public toastController: ToastController,  public navy: NavController) { }

  ngOnInit() {
  }

  pay(){
    this.refs=`${Math.ceil(Math.random() * 10e10)}`
    this.options.amount=this.amnt*100;
    this.options.email=this.usermail
    this.options.ref=this.refs;
this.pays=false;
this.payss=true;
  }

  paymentInit() {
      console.log('Payment initialized');
    }

    paymentDone(ref: any) {
      this.loadingPresent('Please hold on while we process your transactions');
      // this.title = 'Payment successfull';
      // console.log(this.title, ref);
      let body={
        session_id:localStorage.getItem('session_id'),
        amount:this.amnt,
        ref:this.refs,
        method:'add'
      }

      //add the money to the wallet and dismiss the previous modal
      this.provider.add_money(body).subscribe(res=>{
        this.resp=res;
        if (this.resp.message==="success") {
          this.loadingDismiss();
          localStorage.setItem('balance',this.resp.balance);
          this.modalController.dismiss({
          'dismissed': true,
          data:'run'
        });
        }
        else{
          this.loadingDismiss();
          this.presentToast(this.resp.message);

          this.modalController.dismiss({
          'dismissed': true,
          data:'run'
        });
        }
      },err=>{
        this.loadingDismiss();
        this.presentToast(err);

        this.modalController.dismiss({
        'dismissed': true,
        data:'run'
      });
      })
    }
    dismiss(){
      this.modalController.dismiss({
      'dismissed': true,
      data:'run'
    });
    }

    paymentCancel() {
      console.log('payment failed');
      this.presentToast("Payment failed");
      this.modalController.dismiss({
      'dismissed': true,
      data:'run'
    });
    }
    //toast controller here
    async presentToast(params) {
        const toast = await this.toastController.create({
          message: params,
          duration: 2000
        });
        toast.present();
      }
      //loading controller here
      async loadingPresent(params) {
        this.isLoading = true;
        return await this.loadingController.create({
          message:params,
          spinner: 'lines'
        }).then(a => {
          a.present().then(() => {
            console.log('loading presented');
            if (!this.isLoading) {
              a.dismiss().then(() => console.log('abort laoding'));
            }
          });
        });
      }

      async loadingDismiss() {
        this.isLoading = false;
        return await this.loadingController.dismiss().then(() => console.log('loading dismissed'));
      }
      }
